import React, { useState, useEffect } from 'react';
import MyActionListener from '../MyActionListener';
import Square from './Square';
import Keyboard from './Keyboard';
import './CharacterInput.css';

const CharacterInput = () => {

  const [squares, setSquares] = useState(Array(5).fill(''));
  const [borderColor, setBorderColor] = useState('lightgray');
  const dictionary = ['ABCD', 'ABCDE', 'HELLO', 'WORLD'];
  const actionListener = new MyActionListener();

  const isWordInDictionary = (word) => dictionary.includes(word);

  useEffect(() => {
    actionListener.registerListener('CHARACTER_CLICK', handleCharacterClick);
    actionListener.registerListener('BACKSPACE', handleBackspace);
    actionListener.registerListener('ENTER', handleEnter);

    return () => {
      console.log("dan")
      actionListener.removeListener('CHARACTER_CLICK');
      actionListener.removeListener('BACKSPACE');
      actionListener.removeListener('ENTER');
    };
  }, []);

  const handleCharacterClick = (char) => {
    setSquares((prevSquares) => {
      const newSquares = [...prevSquares];
      const emptyIndex = newSquares.indexOf('');
      if (emptyIndex !== -1) {
        newSquares[emptyIndex] = char;
      }
      return newSquares;
    });
  };

  const handleBackspace = () => {
    setSquares((prevSquares) => {
      const newSquares = [...prevSquares];
      const lastFilledIndex = newSquares.lastIndexOf('');
      const indexToClear = lastFilledIndex === -1 ? newSquares.length - 1 : lastFilledIndex - 1;
      if (indexToClear >= 0) {
        newSquares[indexToClear] = '';
      }
      return newSquares;
    });
  };

  const handleEnter = () => {
    const currentWord = squares.join('');
    if (currentWord.length === squares.length) {
      if (isWordInDictionary(currentWord)) {
        setBorderColor('green');
      } else {
        setBorderColor('red');
      }
    } else {
      setBorderColor('red');
    }
  };

  return (
    <div>
      <div id="squares-container">
        {squares.map((char, index) => (
          <Square key={index} char={char} borderColor={borderColor} />
        ))}
      </div>
      <Keyboard actionListener={actionListener} />
    </div>
  );
};

export default CharacterInput;